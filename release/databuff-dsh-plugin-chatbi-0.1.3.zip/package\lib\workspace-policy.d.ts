import { Context } from "@deepseek-ai/cordis";
//#region src/workspace-policy.d.ts
declare const name = "@databuff/dsh-plugin-chatbi/workspace-policy";
declare const inject: string[];
declare const DEFAULT_LINUX_WORKSPACE_ROOT = "/data/logs/dsh/workspace";
interface Config {
  locked?: boolean;
  root?: string;
  agentPreset?: string;
}
declare function resolveWorkspaceRoot(configuredRoot?: string, platform?: NodeJS.Platform, cwd?: string): string;
declare function apply(ctx: Context, input?: Config): Promise<void>;
//#endregion
export { Config, DEFAULT_LINUX_WORKSPACE_ROOT, apply, inject, name, resolveWorkspaceRoot };