import { Context } from "@deepseek-ai/cordis";
//#region src/workspace-policy.d.ts
declare const name = "@databuff/dsh-plugin-chatbi/workspace-policy";
declare const inject: string[];
interface Config {
  locked?: boolean;
  root?: string;
  agentPreset?: string;
}
declare function apply(ctx: Context, input?: Config): Promise<void>;
//#endregion
export { Config, apply, inject, name };