import { Context } from "@deepseek-ai/cordis";
//#region src/policy.d.ts
declare const DEFAULT_ALLOWED_TOOLS: readonly ["getCurrentTimeRange", "getTimeRangeAroundTime", "drawTrendCharts", "queryServicesAll", "queryServicesByServiceType", "queryServiceTopology", "queryTraceListByCondition", "queryTraceDetail", "queryServiceAlarms", "queryMetricData", "queryLogTrend", "queryLogDetail", "queryLogsByTraceId", "queryLogsBySpanId", "inspectService", "listDataTables", "getTableSchema", "searchDataFields", "getMetricCatalog", "queryDorisBusinessData", "querySelfMonitorMetrics", "prometheus_query", "prometheus_query_range", "prometheus_series", "prometheus_metadata"];
declare function publicToolName(rawName: string, serverName?: string): string;
declare function createAllowedToolSet(rawNames?: readonly string[], serverName?: string): ReadonlySet<string>;
declare function isAllowedTool(name: string, allowed: ReadonlySet<string>): boolean;
declare function safeLoginUrl(loginUrl: string, redirectUrl: string): string;
//#endregion
//#region src/index.d.ts
declare const name = "@databuff/dsh-plugin-chatbi";
declare const inject: string[];
interface Config {
  /** Register only the browser contribution when loaded at profile scope. */
  presentationOnly?: boolean;
  /** MCP namespace configured on @deepseek-ai/dsh-mcp-client. */
  serverName?: string;
  /** Raw DataBuff MCP tool names permitted for this agent. */
  allowedTools?: string[];
  /** Require the browser to have a valid DataBuff login. */
  authRequired?: boolean;
  /** Same-origin or CORS-enabled endpoint returning 2xx for a valid login. */
  authStatusUrl?: string;
  /** DataBuff login page. */
  loginUrl?: string;
  /** URL restored after login. Defaults to the current DSH page. */
  redirectUrl?: string;
  /** Milliseconds before the browser rechecks login state. */
  authCheckIntervalMs?: number;
  /** Visible warning when authentication is intentionally disabled. */
  showTestModeBanner?: boolean;
}
declare function normalizeConfig(config?: Config): Required<Config>;
declare function apply(ctx: Context, input?: Config): Promise<void>;
//#endregion
export { Config, DEFAULT_ALLOWED_TOOLS, apply, createAllowedToolSet, inject, isAllowedTool, name, normalizeConfig, publicToolName, safeLoginUrl };